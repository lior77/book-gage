# מחוז פורטו — תיקיית עבודה

## הרצה

```bash
pip install reportlab python-bidi shapely
python3 porto_map.py     # מייצר porto_district_map_a3.pdf (19 עמודים)
```

דרוש הגופן DejaVu Sans, שנטען מ-`/usr/share/fonts/truetype/dejavu/`.
במק או בחלונות יש לעדכן את הנתיב בראש `porto_map.py`.

## הקבצים

| קובץ | תוכן |
|---|---|
| `BRIEF.md` | הבריף המלא — מה חסר, מאיפה להשלים, ומה לבנות |
| `porto_map.py` | הסקריפט הראשי שמייצר את ה-PDF |
| `porto_pages.py` | `PROFILES` — טקסטים ל-18 העיריות |
| `porto_freg2.py` | `BELTS`, `TRANSPORT`, `PENDING2` — חגורות ותחבורה |
| `porto_freg3.py` | `FREG3` — 140 פרגזיות: שם עברי, אנגלי, אוכלוסייה 2021, תיאור |
| `porto_city.py` | `PORTO_FREG`, `BAIRROS` — 7 הרבעים ו-53 השכונות של פורטו |
| `porto_geo.py` | הטלה + חיפוש שמות מקום בתוך רובע |
| `porto_dist_geo.py` | גיאומטריה של 18 העיריות (shapely) |
| `data/*.geojson` | גבולות OpenStreetMap (ODbL — נדרש קרדיט) |
| `porto_mapa_interativo.html` | מפת SVG אינטראקטיבית, ללא תלויות |

## מבני הנתונים המרכזיים

```python
PROFILES[n] = (english, hebrew, belt_colour, [(label, text), ...])
FREG3[n]    = [(hebrew, english, pop_2021_or_None, description), ...]
BAIRROS[n]  = (title_he, title_en, colour, [(col,row,span,he,en,desc), ...])
TRANSPORT[n]= "תיאור התחבורה לפורטו"
DIST[n]     = "מרחק אווירי בק\"מ"
```

`n` הוא מספר העירייה 1–18, לפי המספור במסמך.
