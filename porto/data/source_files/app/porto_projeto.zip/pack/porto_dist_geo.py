import json, math
from shapely.geometry import shape, mapping
from shapely.ops import unary_union

import os
SRC = os.path.join(os.path.dirname(__file__), "data", "porto_municipios.geojson")
_d = json.load(open(SRC))

MUNI = {}
for f in _d["features"]:
    p = f["properties"]
    if p.get("admin_level") == "7" and p.get("name"):
        MUNI[p["name"]] = shape(f["geometry"]).buffer(0)

NAME = {1:"Porto",2:"Vila Nova de Gaia",3:"Matosinhos",4:"Maia",5:"Gondomar",
        6:"Valongo",7:"Vila do Conde",8:"Póvoa de Varzim",9:"Santo Tirso",
        10:"Trofa",11:"Paredes",12:"Penafiel",13:"Paços de Ferreira",
        14:"Lousada",15:"Felgueiras",16:"Amarante",17:"Marco de Canaveses",18:"Baião"}

def geom(n):
    return MUNI[NAME[n]]

def belt_union(nums):
    return unary_union([geom(n) for n in nums])

def all_bounds():
    return unary_union(list(MUNI.values())).bounds

def make_proj(x0, y0, w, h, pad=6):
    lo0, la0, lo1, la1 = all_bounds()
    k = math.cos(math.radians((la0 + la1) / 2.0))
    W = (lo1 - lo0) * k
    H = (la1 - la0)
    s = min((w - 2*pad) / W, (h - 2*pad) / H)
    ox = x0 + (w - W*s) / 2.0
    oy = y0 + (h - H*s) / 2.0
    def proj(pt):
        return (ox + (pt[0]-lo0)*k*s, oy + (pt[1]-la0)*s)
    return proj

def rings(g):
    out = []
    gs = [g] if g.geom_type == "Polygon" else list(g.geoms)
    for poly in gs:
        out.append(list(poly.exterior.coords))
        for r in poly.interiors:
            out.append(list(r.coords))
    return out

def label_point(n):
    p = geom(n).representative_point()
    return (p.x, p.y)
